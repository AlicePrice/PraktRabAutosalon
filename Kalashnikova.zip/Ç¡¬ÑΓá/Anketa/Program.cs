﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Anketa
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello, do not want to buy a questionnaire? Answer y or n.");
            string answer = Console.ReadLine();
            switch (answer) {
                case "y":
                    Console.WriteLine("Good. Let's start!");
                    break;
                case "n":
                    Console.WriteLine("Goodbye then :)");
                    Environment.Exit(0);
                    break;
                default:
                    Console.WriteLine("Something went wrong.");
                    Environment.Exit(0);
                    break;
            }
            Console.WriteLine("Now fill in your profile :)");
            Console.WriteLine("Your login:");
            string Login = Console.ReadLine();
            Console.WriteLine("Your surname?");
            string Surname = Console.ReadLine();
            Console.WriteLine("Your name?");
            string Name = Console.ReadLine();
            Console.WriteLine("Place of Birth?");
            string Place = Console.ReadLine();
            Console.WriteLine("How old are you?");
            string Years = Console.ReadLine();
            Console.WriteLine("Your gender?");
            string Gender = Console.ReadLine();
            Console.WriteLine("Where do you study?");
            string PlaceOfStudy = Console.ReadLine();
            Console.WriteLine("Your group?");
            string Group = Console.ReadLine();
            Console.WriteLine("All is ready! Show your profile?");
            Console.WriteLine("Answer y or n.");
            string answer2 = Console.ReadLine();
            switch (answer2)
            {
                case "y":
                    Console.WriteLine("Good! Please see.");
                    break;
                case "n":
                    Console.WriteLine("See you!");
                    Environment.Exit(0);
                    break;
                default:
                    Console.WriteLine("Something went wrong.");
                    Environment.Exit(0);
                    break;
            }
            Console.WriteLine("Profile:" + "\n ** ** ** ** ** ** ** ** ** " +
                                    "\n        * * VIEW * * " +
                                    "\n * YOUR PROFILE * * " +
                                    "\n * " + (Login) + " * * " +
                                            "\n **************************" +
                                    "\n * NAME AND PLACE OF BIRTH: " + (Name) + ", " +(Surname) + ", " + (Place) + "; *" +
                                    "\n * YEARS: " + (Years) + "; * " +
                                    "\n * GENDER: " + (Gender) + "; * " +
                                    "\n * PLACE OF STUDY: " + (PlaceOfStudy) + "; * " +
                                    "\n * GROUP: " + (Group) + "; *" +
                                            "\n ************************* ");


                    Console.ReadKey();

        }
    }
}
