﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp444
{
    class Program
    {
        static void Main(string[] args)
        {
            {
                string Summ;
                Console.WriteLine("Введи первое число");
                int FerstNumber = int.Parse(Console.ReadLine());
                Console.WriteLine("Введите второе число");
                int SecondNumber = int.Parse(Console.ReadLine());

                int Step = 0;
                Summ = Console.ReadLine();
                while (Step <= 1000)
                {
                    Step++;
                    FerstNumber++;

                    SecondNumber++;
                    Console.WriteLine("" + (FerstNumber + SecondNumber));

                
                }
                Console.WriteLine(FerstNumber);
                Console.WriteLine(SecondNumber);
                Console.ReadKey();
            }
        }
    }
}
