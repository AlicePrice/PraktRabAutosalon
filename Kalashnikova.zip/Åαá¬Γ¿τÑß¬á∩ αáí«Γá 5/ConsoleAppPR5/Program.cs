﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleAppPR5
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Приветствую тебя, дорогой мой друг");
            Console.WriteLine("Хочешь узнать один рандом факт из мира IT?");
            Console.WriteLine("напиши ДА или НЕТ");
            string answer = Console.ReadLine();
            switch (answer)
            {
                case "ДА":
                    Console.WriteLine("");
                    break;
                case "НЕТ":
                   
                    Environment.Exit(0);
                    break;
                default:
                    Console.WriteLine("Ну тогда приступим :)");
                    Environment.Exit(0);
                    break;
            }
            int chislo;
            do
            {
                Console.WriteLine("Введите число от 1 до 10");
                chislo = Convert.ToInt32(Console.ReadLine());
                if (chislo < 1 || chislo > 10)
                    Console.WriteLine("Данного числа нет в нашей программе...");
            }
            while (chislo < 1 || chislo > 10);
            switch (chislo)
            {
                case 1:
                    {
                        Console.WriteLine("Первый в истории компьютерный баг был найден 69 лет назад. Это была... обычная моль,");
                        Console.WriteLine("которая залетела в компьютер Mark II в Гарварде в 1945 году и застряла между контактами электромеханического реле.");
                        break;
                    }
                case 2:
                    {
                        Console.WriteLine("В 1956 году IBM выпустила первый <<супер>> компьютер,");
                        Console.WriteLine("который был оснащен жестким диском 305 Ramac. ");
                        Console.WriteLine("На то время технология казалась революционной, ");
                        Console.WriteLine("но сейчас выглядит по меньшей мере забавной:");
                        Console.WriteLine("винчестер весил более тонны и мог вместить <<колоссальные>> 5 мегабайт данных.");
                        break;
                    }
                case 3:
                    {
                        Console.WriteLine("В 1978 году компания Apple Corps, которая принадлежала Битлз,");
                        Console.WriteLine("подала в суд на Apple Computer (официальное название Apple до 2007 года) за нарушение товарного знака.");
                        Console.WriteLine("В итоге компании пришли к соглашению, что Apple Computer пообещала никогда не");
                        Console.WriteLine("заниматься музыкальным бизнесом, а Apple Corps - компьютерным бизнесом.");
                        break;
                    }
                case 4:
                    {
                        Console.WriteLine("94% всех е-мейл посланий – это спам, их количество составило 22 млрд.,");
                        Console.WriteLine("объёмом в 86,5 терабайт.");
                        break;
                    }
                case 5:
                    {
                        Console.WriteLine("Самая большая компьютерная сеть насчитывает 6 тыс. машин, она обслуживает Большой Андронный Коллайдер.");
                        break;
                    }
                case 6:
                    { 
                        Console.WriteLine("По статистике ежедневно на стандартную компьютерную сеть происходит более 20 вирусных атак.");
                        break;
                    }
                case 7:
                    {
                        Console.WriteLine("Символично для нашего времени то, что в 1982 году Человеком Года по версии журнала  «Time» был признан «Компьютер».");
                        break;
                    }
                case 8:
                    {
                        Console.WriteLine("Создатели Windows включили популярные развлекательные приложения «Сапер» и «Косынка» в операционную систему не для того, чтобы скрасить досуг пользователя.");
                        Console.WriteLine("Подобные игры призваны обучить новичка пользоваться мышью и адаптироваться к графическому интерфейсу.");
                        break;
                    }
                case 9:
                    {
                        Console.WriteLine("Домен YouTube был зарегистрирован в День Влюбленных. На данный момент половина его пользователей не достигла 20 лет,");
                        Console.WriteLine("а более 70% живут в США и Великобритании. Второе место по количеству просмотров занимает Япония.");
                        break;
                    }
                default:
                    {
                        Console.WriteLine("Только в России и СНГ знак @ называют собакой. В других странах этот символ известен в качестве улитки или обезьяны. ");
                        Console.WriteLine("Впервые он был использован в 1972 году создателем первого в мире электронного письма Рейем Томлинсоном.");
                        break;
                    }
                      
            }
            Console.ReadKey();

        }
    }
}
